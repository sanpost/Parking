var searchData=
[
  ['v_5fcol_0',['V_col',['../struct_position.html#a7bf21b4ba5c3e011c16b03aa3108870d',1,'Position']]],
  ['v_5frow_1',['V_row',['../struct_position.html#aeef33f5fb4ba6930e778e46994ff8359',1,'Position']]]
];
