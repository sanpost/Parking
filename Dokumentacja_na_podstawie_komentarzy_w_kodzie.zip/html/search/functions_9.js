var searchData=
[
  ['truck_0',['Truck',['../class_truck.html#a87e358bca8fe34e6299c6ff233afb08b',1,'Truck']]]
];
