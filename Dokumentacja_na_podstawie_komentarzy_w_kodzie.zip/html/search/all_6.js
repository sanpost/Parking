var searchData=
[
  ['getboardheight_0',['getBoardHeight',['../class_parking___place.html#a9e220c228b9b2daf64a6f3570af122a1',1,'Parking_Place']]],
  ['getboardwidth_1',['getBoardWidth',['../class_parking___place.html#a4fd5f7cab22683c3985931da78a28134',1,'Parking_Place']]]
];
