Aby otworzyć pełną dokumntację proszę wybrać folder 'doc files'
a następnie znaleźć plik 'index.html'
dokumtacja powinna otowrzyć się w przeglądarce 
 