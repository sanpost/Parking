var class_vehicle =
[
    [ "check_parking_spot_in", "class_vehicle.html#a9deaf016160b4a4ec4ef2ea1a33fed8f", null ],
    [ "check_parking_spot_out", "class_vehicle.html#ad728be8e372731a2e509bd9cc269f537", null ],
    [ "leave_parking_spot", "class_vehicle.html#a920fd743dd18e60687f8fee27247a4a3", null ],
    [ "move", "class_vehicle.html#af704110c7c18bb8d9a3066dcf9dad7b0", null ],
    [ "park", "class_vehicle.html#a7ca0c65e367431e7a9766799b7d7dcc9", null ],
    [ "SetVehicleOnBoard", "class_vehicle.html#aa11c5de3ec865c9baaea72eac86b9d2c", null ]
];