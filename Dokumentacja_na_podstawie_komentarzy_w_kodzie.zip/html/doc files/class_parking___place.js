var class_parking___place =
[
    [ "Parking_Place", "class_parking___place.html#a7d8e587c070e7ad7e1391f979d5d8104", null ],
    [ "ChangeFieldInfo", "class_parking___place.html#a3b224999e929637868bb8bb7f18ff965", null ],
    [ "Count_free_parking_spots", "class_parking___place.html#ac5a6683d8f392cd73bc8f582e2b96584", null ],
    [ "Count_taken_parking_spots", "class_parking___place.html#a889e3ff7803288ad131db994a58bfb85", null ],
    [ "getBoardHeight", "class_parking___place.html#a9e220c228b9b2daf64a6f3570af122a1", null ],
    [ "getBoardWidth", "class_parking___place.html#a4fd5f7cab22683c3985931da78a28134", null ],
    [ "isPlaceParking", "class_parking___place.html#a03d4c44409bee28a3c221978ad611ee8", null ],
    [ "isPlaceTaken", "class_parking___place.html#a06f9724861ab590a1ceb797efd88bc26", null ],
    [ "WhatVehicle", "class_parking___place.html#a660f9c1212d235f1793c110d90d8779b", null ]
];