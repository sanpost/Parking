var class_truck =
[
    [ "Truck", "class_truck.html#a87e358bca8fe34e6299c6ff233afb08b", null ],
    [ "check_parking_spot_in", "class_truck.html#a676f88de0c0294230be16866185bf5d5", null ],
    [ "check_parking_spot_out", "class_truck.html#a3f83bc362bb5351a3a34c7bdd724d98d", null ],
    [ "leave_parking_spot", "class_truck.html#a3963f1b8c14e4e0ddd242016f732894c", null ],
    [ "move", "class_truck.html#a7ae32f7f6e7a596715a745e875c93601", null ],
    [ "park", "class_truck.html#aec89a0a25c129f28a7c19aae5d80d1ed", null ],
    [ "SetVehicleOnBoard", "class_truck.html#aba2463034f913dc53231d2b711364092", null ]
];