var hierarchy =
[
    [ "Field", "struct_field.html", null ],
    [ "Parking_Place", "class_parking___place.html", null ],
    [ "Position", "struct_position.html", null ],
    [ "SFMLParking", "class_s_f_m_l_parking.html", null ],
    [ "Vehicle", "class_vehicle.html", [
      [ "Bike", "class_bike.html", null ],
      [ "Car", "class_car.html", null ],
      [ "Truck", "class_truck.html", null ]
    ] ]
];