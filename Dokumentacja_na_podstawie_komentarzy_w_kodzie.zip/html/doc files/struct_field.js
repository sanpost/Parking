var struct_field =
[
    [ "isParking", "struct_field.html#a79e889b0dca1cb83bf38aad9aa9b13de", null ],
    [ "isTaken", "struct_field.html#a2da90b9137ee823b7cf60c88e5d1a5f3", null ],
    [ "what_vehicle", "struct_field.html#ae87d8b3e9f965f53e82f66f61d8a8bb3", null ]
];