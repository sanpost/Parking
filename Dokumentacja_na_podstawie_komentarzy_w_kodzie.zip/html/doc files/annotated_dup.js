var annotated_dup =
[
    [ "Bike", "class_bike.html", "class_bike" ],
    [ "Car", "class_car.html", "class_car" ],
    [ "Field", "struct_field.html", "struct_field" ],
    [ "Parking_Place", "class_parking___place.html", "class_parking___place" ],
    [ "Position", "struct_position.html", "struct_position" ],
    [ "SFMLParking", "class_s_f_m_l_parking.html", "class_s_f_m_l_parking" ],
    [ "Truck", "class_truck.html", "class_truck" ],
    [ "Vehicle", "class_vehicle.html", "class_vehicle" ]
];